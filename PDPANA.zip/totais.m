%% **************** FALTANTES-MÁXIMOS-MÍNIMOS-TOTAIS **********************
%
% Está função emprega como variavéis de entrada os ressultados da função
% depurar, e fornece como resultados os dados faltantes, máximos, minimos e
% totais mensais de precipitação. 

%Diretorio = diretorio dos dados depurados


function [faltantes,maximos,minimos,totais, medias, precipitacao, percentagem_faltante, anos_registro, total_faltante, ano_i, ano_f]= totais (dados_depurados)

% Leitura do arquivo
 



%% Gerando o vetor das datas

tamano= size(dados_depurados);

% data incial
x=dados_depurados(1,1);
x=datevec(x);
dia_i=x(3);
mes_i=x(2);
ano_i=x(1);

%data final

x=dados_depurados(tamano(1),1);
x=datevec(x);
dia_f=x(3);
mes_f=x(2);
ano_f=x(1);

% Gerando o vetor (dia/mes/ano) 

I=datetime(ano_i,mes_i,dia_i);
f=datetime(ano_f,mes_f,dia_f);

%Gerando o Vetor de anos

v_anos= (ano_i:ano_f)';


datas =(I:f)';
dados = size(datas,1);


%% TABELA DE MÀXIMOS MINIMOS E FALTANTES 
   
% Criando tabelas com valores nulos a serem preenchidos posteriormente

   maximos   =repmat(-999,size(v_anos,1),12);  %Precipitação máxima diária mensal
   minimos   =repmat(-999,size(v_anos,1),12);  %Precipitação minima diária mensal
   medias    =repmat(-999,size(v_anos,1),12);  %Precipitação media diária  mensal
   totais    =repmat(-999,size(v_anos,1),12);  %Precipitação total mensal
   faltantes =repmat(-999,size(v_anos,1),12);        %Dados Faltantes mensais

%% MÁXIMOS MINIMOS TOTAIS E FALTANTES

z= 0 ;                   % Contador de datos del vector Datas

for i=1:size(dados_depurados,1);
    
    x=datevec(dados_depurados(i,1));
    ano=x(1);
    mes= x(2);
    dia_final=eomday(ano,mes);
    
    %% TOTAIS-MÁXIMOS-MEDIOS-MINIMOS E FALTANTE
    
    maximos(find(v_anos==ano),mes)= max(dados_depurados(i,3:dia_final+2));
    minimos(find(v_anos==ano),mes)= min(dados_depurados(i,3:dia_final+2));
    faltantes(find(v_anos==ano),mes)= sum(isnan(dados_depurados(i,3:dia_final+2)));
    xxx=~isnan(dados_depurados(i,1:dia_final+2));  %dados com registros
    
    if faltantes(find(v_anos==ano),mes)==dia_final 
    totais(find(v_anos==ano),mes)=str2num('NaN');
    medias(find(v_anos==ano),mes) = str2num('NaN');
    else
    totais(find(v_anos==ano),mes)=sum((dados_depurados(i,xxx)))-sum((dados_depurados(i,1:2)));
    medias(find(v_anos==ano),mes) = totais(find(v_anos==ano),mes)/dia_final; 
    end
        

    
    
    %% VETOR COM REGISTROS DIARIOS
     
    for ii=1:dia_final
        precipitacao(ii+z,1)=datenum(datetime(ano,mes,ii));
        precipitacao(ii+z,2)= dados_depurados(i,ii+2);
    end
    
    z=z+dia_final;
end
   
%% gerando as matrizes com as análise finais

   maximos=horzcat(v_anos,maximos);
   minimos=horzcat(v_anos,minimos);
   faltantes=horzcat(v_anos,faltantes);
   totais =horzcat(v_anos,totais);
   medias=horzcat(v_anos,medias);


%% AJUSTANDO OS FALTANTES

%Nesta parte do código é designado o número de dados faltantes para os
%meses que não se encontrabam no arquivo fornecido pela ANA (substitui o -999
%pelo número de dias do mês), e atribui Nan para os meses fora do periodo
%de intalação da estação.


  for i=1:size(faltantes,1)  %corre pelas filas (anos)
       
       
        for ii=2:13    %corre pelas colunas (meses)
            
            if ano_i == faltantes(i,1) && mes_i>ii-1
              faltantes(i,ii)= nan;
            
            elseif ano_i == faltantes(i,1) && mes_i<=ii-1 && faltantes(i,ii)==-999
              faltantes(i,ii)= eomday(faltantes(i,1),ii-1);
            end
            
  
            if ano_i<faltantes(i,1) && ano_f>faltantes(i,1) && faltantes(i,ii)==-999
              faltantes(i,ii)= eomday(faltantes(i,1),ii-1);
            end
            
            if  ano_f==faltantes(i,1) && mes_f<ii-1
                faltantes(i,ii)= nan;
            elseif ano_f==faltantes(i,1) && mes_f>=ii-1 && faltantes(i,ii)==-999
                 faltantes(i,ii)= eomday(faltantes(i,1),ii-1);
            end
            
        end  
       
  end
  
%%   Percentagem de dados faltantes
      
    
x=~isnan(faltantes(:,:));
total_faltante=sum(faltantes(x))-sum(faltantes(:,1));
percentagem_faltante = total_faltante/dados *100; 
anos_registro= ano_f-ano_i +1;


%% GERANDO TABELAS DE SAIDA
%
%MAXIMOS
   
   ano=maximos(:,1);
   jan=maximos(:,2);
   fev=maximos(:,3);
   mar=maximos(:,4);
   abr=maximos(:,5);
   mai=maximos(:,6);
   jun=maximos(:,7);
   jul=maximos(:,8);
   ago=maximos(:,9);
   set=maximos(:,10);
   out=maximos(:,11);
   nov=maximos(:,12);
   dez=maximos(:,13);
   
   maximos=table(ano, jan, fev, mar, abr, mai, jun, jul, ago, set, out, nov, dez);

%MINIMOS

   ano=minimos(:,1);
   jan=minimos(:,2);
   fev=minimos(:,3);
   mar=minimos(:,4);
   abr=minimos(:,5);
   mai=minimos(:,6);
   jun=minimos(:,7);
   jul=minimos(:,8);
   ago=minimos(:,9);
   set=minimos(:,10);
   out=minimos(:,11);
   nov=minimos(:,12);
   dez=minimos(:,13);
   
   minimos=table(ano, jan, fev, mar, abr, mai, jun, jul, ago, set, out, nov, dez);
   
 % FALTANTES
 
   ano=faltantes(:,1);
   jan=faltantes(:,2);
   fev=faltantes(:,3);
   mar=faltantes(:,4);
   abr=faltantes(:,5);
   mai=faltantes(:,6);
   jun=faltantes(:,7);
   jul=faltantes(:,8);
   ago=faltantes(:,9);
   set=faltantes(:,10);
   out=faltantes(:,11);
   nov=faltantes(:,12);
   dez=faltantes(:,13);
   
   faltantes=table(ano, jan, fev, mar, abr, mai, jun, jul, ago, set, out, nov, dez);
 
 % TOTAIS
 
    ano=totais(:,1);
   jan=totais(:,2);
   fev=totais(:,3);
   mar=totais(:,4);
   abr=totais(:,5);
   mai=totais(:,6);
   jun=totais(:,7);
   jul=totais(:,8);
   ago=totais(:,9);
   set=totais(:,10);
   out=totais(:,11);
   nov=totais(:,12);
   dez=totais(:,13);
   
   totais=table(ano, jan, fev, mar, abr, mai, jun, jul, ago, set, out, nov, dez);
 
 % MEDIAS
 
    ano=medias(:,1);
   jan=medias(:,2);
   fev=medias(:,3);
   mar=medias(:,4);
   abr=medias(:,5);
   mai=medias(:,6);
   jun=medias(:,7);
   jul=medias(:,8);
   ago=medias(:,9);
   set=medias(:,10);
   out=medias(:,11);
   nov=medias(:,12);
   dez=medias(:,13);
   
   medias=table(ano, jan, fev, mar, abr, mai, jun, jul, ago, set, out, nov, dez);
 
 %VETOR
   
  datas=datestr(precipitacao(:,1));
  precipitacao_mm=precipitacao(:,2);
  precipitacao=table(datas,precipitacao_mm);

end
