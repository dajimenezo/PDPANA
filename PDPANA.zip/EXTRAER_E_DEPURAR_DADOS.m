

%                     INFORMAÇÃO SUBMINISTRADA PELO USUARIO
%--------------------------------------------------------------------------
%
% DIRETORIOS
%
dir_central= addpath('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA');                 %Pasta onde foi armazenado o programa
diretorio_entrada =('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\registros_base') ;    %Pasta com dados brutos em csv
diretorio_saida= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Dados_depurados');    %Pasta para salvar dados depurados 
dir_maximo= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Maximos');               %Pasta Para salvar maximos
dir_min= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Minimos');                  %Pasta para salvar Minimos
dir_tot= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Totais');               %Pasta para salvar Totais
dir_med= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Medios');               %Pasta para salvar Val Medios
dir_fal= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Dados_faltantes');                  %Pasta para salvar faltantes
dir_col= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Dados_col');                  %Pasta para salvar dados Col            
dir_resu= ('E:\1.3 ACADEMIA_\3.16 PROGRAMAS PUBLICADOS\PDPANA\PROGRAMA\Resumo');

%##########################################################################

%               OBTENÇÃO DO NOME DAS ESTAÇÕES PLUVIOMÉTRICAS
%--------------------------------------------------------------------------
%% 
Nomes_estacoes=extrair_nomes(diretorio_entrada);   %Retorna nome dos arquivos de precipitação
n = size(Nomes_estacoes,1);

b1=barh(n);
hold on;
linkdata on;
xlabel('NUMERO DE ESTAÇÕES');
xlim([0 n])
yticks(1);
yticklabels("ESTAÇÕES PROCESSADAS");

%%
for j=1:n

%Fazendo o gráfico do estado de preocessamento


barra1=barh(j);
barra1.FaceColor=[0 1 0];
barra1.EdgeColor= 'w';    
pause(0.1)


% DADOS PROCESSADOS    
input=convertStringsToChars(Nomes_estacoes(j));        % trocar o um por i 
[output,dados_depurados1]= depurar(input,diretorio_entrada,diretorio_saida);
nome_saida = strcat('Pros_',input);
writetable(output, nome_saida,'Delimiter',';');
clc;

% MAXIMOS, MINIMOS, TOTAIS, MEDIOS, FALTANTES E VETOR DE DADOS  

%[faltantes,maximos,minimos,totais, medias, precipitacao, percentagem_faltante, anos_registro]= totais (dados_depurados1);
[faltante, maximo, minimo, total, media, coluna, pf, an, tf, ai, af]= totais(dados_depurados1);


%MAXIMOS
cd(dir_maximo)
nome_saida = strcat('MAX_',input);
writetable(maximo, nome_saida,'Delimiter',';');



%MINIMOS
cd(dir_min)
nome_saida = strcat('MIN_',input);
writetable(minimo, nome_saida,'Delimiter',';');

%TOTAIS
cd(dir_tot)
nome_saida = strcat('TOT_',input);
writetable(total, nome_saida,'Delimiter',';');

%MEDIOS
cd(dir_med)
nome_saida = strcat('MED_',input);
writetable(media, nome_saida,'Delimiter',';');

%FALTANTES

cd(dir_fal)
nome_saida = strcat('FAL_',input);
writetable(faltante, nome_saida,'Delimiter',';');

%DADOS EN COLUNA

cd(dir_col)
nome_saida = strcat('COL_',input);
writetable(coluna, nome_saida,'Delimiter',';');

%PERCENTAGEM FALTANTE

p_faltante(j)= pf;

%ANOS DE REGISTRO

A_registro(j)= an;

%TOTAL DE DADOS FALTANTES

total_faltantes(j)= tf;

%Ano inicial 

Ano_inicial(j)=ai;
Ano_final (j)=af;





 



end


cd(dir_resu);

Nome_da_estacao = Nomes_estacoes;
Num_dados_faltantes = total_faltantes';
Per_faltante= p_faltante';
Anos_registro= A_registro';
Ano_inicial=Ano_inicial';
Ano_final=Ano_final';
resumo= table(Nome_da_estacao, Num_dados_faltantes, Per_faltante, Ano_inicial, Ano_final, Anos_registro);
writetable(resumo, 'sumario.csv','Delimiter',';');

%%PREPARAÇÃO PARA A GERAÇÃO DO GRÁFICO DE REGISTROS TEORICOS; 
%
%OBS: não considera os registros faltantes, apresenta os registros teoricos
%que deberia conter o arquivo. 

resumo= table(Nome_da_estacao, Ano_inicial, Ano_final);
G_registros(resumo)



%clear