%% GERAÇÃO DE GRÁFICO COM OS REGISTOS DIPONIVEIS
%
%A presente função tem como o objetivo a geração de um gráfico que
%apresente os anos com registros pluviometricos disponivéis. 
%
% visto que só são fornecidos o ano  inicial e final dos resgistros o
% programa não consegui identificar os períodos intermedios  faltantes
% motivo pelo cual estes deverão ser identificados no arquivo de faltantes.
% 
%% CARATERISTICA DOS DADOS DE ENTRADA:
%
%Os dados deverão ter a seguinte configuração: 
%
%  | Nome Estação | Ano inicial | Ano Final |
%
% Sendo: 
%
%    Ano inicial: Ano de inicio dos registros pluviometricos. 
%    Ano Final: Ano onde finalizam os registros pluviometricos.

function []=G_registros(dados)

   Nome_estacao= table2array(dados(:,1));
   Ano_inicial = table2array(dados(:,2));
   Ano_final   = table2array(dados(:,3));
   
   
  %% GERANDO OS NOMES DAS ESTAÇÕES PARA O GRAFICO     
       old="chuvas_C_";
       new1="E. ";
       new2="";
       old1=".csv";
       
       nome_est = replace(Nome_estacao,old,new1);
       nome_est= replace(nome_est,old1,new2);
       
   %%ARRANJANDO O VETOR DE COLUMA PARA FILA 
   
   for i=1:size(Nome_estacao,1);
   nome_estacao(i)=nome_est(i);
   end 
   
   %% Gerando o Grafico
   b=(horzcat(Ano_inicial, Ano_final));
   b1=barh(b(:,2));
   hold on;
   b2=barh(b(:,1));
   b2.FaceColor=[1 1 1];
   b2.EdgeColor= 'w';
   li=min(Ano_inicial)-10;  %Limite inferior do gráfico 
   ls=max(Ano_final)+10;    %Limite superior do gráfico
   xlim([li ls]);
   xlabel('Ano');
   ylabel('Estação');
   yticks(1:size(Ano_inicial,1))
   yticklabels(nome_estacao);
   hold off
   
   
   saveas(gcf,'Registros.png')
   
end
