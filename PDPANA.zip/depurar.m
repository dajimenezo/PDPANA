
function [dados_depurados,dados_depurados1]=depurar(arquivo, diretorio,diretorio_saida)
% Leitura do 
cd(diretorio); 
%arquivo= 'chuvas.csv';
x=readtable(arquivo);
%% 
%Arrumando os dados
chuva=x(:,14:44);
data=x(:,3);
consistencia=x(:,2);
data=table(data,consistencia,chuva);
data=table2array(data);
clear x chuva consistencia;

%% 

%Gerando as Variaveis
datas=table2array(data(:,1));
consistencia=table2array(data(:,2));
chuva=table2array(data(:,3:33));
clear data arquivo;

%% 
%Transformação de data para numero

datas2=datenum(datas);
datas2=datevec(datas2);
ano= datas2(:,1);
mes= datas2(:,3);
dia= datas2(:,2);
datas2=datenum(ano,mes,dia);

clear ano mes dia;

%% gerando Nova tabela  : | DATA | CONSISTENCIA | CHUVA |

dados=[datas2,consistencia,chuva];
dados=sortrows(dados,[1 2]);
clear chuva consistencia datas datas2;


%% Removendo dados Repetidos

dados_repetidos=[];
n=size(dados,1);
z=0;
for i=1:n

    if size(find(dados(i:n,1)==dados(i,1)),1)>1
        dados_repetidos=find(dados(:,1)==dados(i,1));
    end
end

clear dados_repetidos n z;



%% Deixando dados consistidos

dados_depurados=[];
n=size(dados,1);
z=0;

for i=1:n
     
    
     if size(find(dados(i:n,1)==dados(i,1)),1)>1
        z=z+1;
        localiza=find(dados(:,1)==dados(i,1));
       
        if dados(localiza,2)==2 ==true
        a= dados(localiza,2)==2 ;
        b= find(a);
        posicao=localiza(b);
        dados_depurados(z,1:33)=dados(posicao,1:33);
        else
        dados_depurados(z,1:33)=dados(localiza(2),1:33);    
        end
        
        
     elseif   size(find(dados(1:i,1)==dados(i,1)),1)>1
     
     else 
         z=z+1;
         dados_depurados(z,1:33)=dados(i,1:33);
     end

      
end

clear a b i localiza n posicao z;
cd(diretorio_saida);

%%   Gerando tabela para sere exportada.

dia=datestr(dados_depurados(:,1));
consistencia=dados_depurados(:,2);

for i=3:33
    eval(sprintf('Pr_%d = dados_depurados(:,i)',i-2));
end

dados_depurados1=dados_depurados;

dados_depurados=table(dia, consistencia, Pr_1 ,Pr_2 ,Pr_3 ,Pr_4 ,Pr_5,...
    Pr_6 ,Pr_7 ,Pr_8 ,Pr_9 ,Pr_10 ,Pr_11 ,Pr_12 ,Pr_13 ,Pr_14,Pr_15,... 
    Pr_16,Pr_17,Pr_18,Pr_19,Pr_20,Pr_21,Pr_22,Pr_23,Pr_24,Pr_25,...
    Pr_26,Pr_27,Pr_28,Pr_29,Pr_30,Pr_31);



end 






